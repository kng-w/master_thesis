# ACMMM2025 リバタル Rebuttal 準備

Tag: Research Log (https://www.notion.so/Research-Log-64b6c6130e5341db8d1b5ac4f5ac0836?pvs=21)
Created Date: June 11, 2025 → June 19, 2025
RECORD: PosterLlama (https://www.notion.so/PosterLlama-2136833ec28b807da88af839ab3a8263?pvs=21)

# OpenReview

---

[](https://openreview.net/forum?id=igrR5GZdB3#discussion)

# Review まとめ

---

## Reviewer 1

- Review 本文
    
    **Review of Submission 4528**
    
    Official Reviewby Reviewer ryDR25 May 2025, 19:37 (modified: 09 Jun 2025, 23:38)Program Chairs, Senior Area Chairs, Area Chairs, Reviewer ryDR, Authors[Revisions](https://openreview.net/revisions?id=v2ILv2Stsj)
    
    **Review:**
    
    Summary:
    
    The paper presents Manga109Script, a newly constructed dataset comprising script data for approximately 20,000 manga pages from the Manga109 dataset. The primary objective is to facilitate the Script2Layout task, where narrative scripts are used to generate coherent and expressive manga layouts. Utilizing Vision Large Language Models (VLLMs) such as GPT-4, the authors generate scripts that include scene headings, action descriptions, and dialogues. They then develop and evaluate several Script2Layout models, demonstrating that incorporating script information significantly enhances layout generation quality compared to existing methods. The dataset and associated code are to be made available upon publication, providing a valuable resource for future research in manga layout generation and visual storytelling.
    
    Strengths
    
    1. The introduction of Manga109Script addresses a significant gap in the domain of manga layout generation by providing a large-scale, script-aligned dataset. This enables the exploration of script-based layout generation, which has been under-researched due to data scarcity.
    2. The authors employ a robust method for script generation using VLLMs with visual prompting and speaker-aware dialogue sequencing. The multi-step interaction with GPT-4 ensures that the scripts are contextually coherent and aligned with the original manga narratives.
    3. Human evaluation metrics such as Scene Heading Recall, Scene Heading Precision, Action Description Precision, Out-of-Context Action Description Detection Accuracy, and Dialogue Recall add credibility to the dataset's quality, demonstrating its reliability for downstream tasks.
    4. The paper is well-structured, with clear explanations of the problem formulation, data construction process, and experimental setup. Figures and tables are effectively used to illustrate key points and results.
    
    Weaknesses
    
    1. The script generation process relies on GPT-4. This dependence may raise concerns regarding reproducibility and reliability.
    2. While the paper provides quantitative and qualitative evaluations, it lacks a detailed error analysis. Understanding the common failure modes of the Script2Layout models could provide deeper insights and guide future improvements.
    3. The evaluation primarily focuses on comparisons with existing layout generation methods. Exploring alternative script generation techniques or incorporating multiple VLLMs could strengthen the experiment part.
    
    **Rating:** 6: Marginally above acceptance threshold
    
    **Confidence:** 4: The reviewer is confident but not absolutely certain that the evaluation is correct
    
    **Fit:** Very clearly a multimedia paper, of interest to a large part of the community
    
    **Fit Justification:**
    
    Script2Layout is a multimedia task.
    
    **Technical Quality:** 5
    
    **Presentation Quality:** 6
    
    **Rebuttal Questions:**
    
    Please refer to the weakness part.
    
    **Additional Comments:**
    
- 日本語要約
    
    **レビュー概要：**
    
    本論文は、Manga109データセットから約20,000ページのマンガに対応するスクリプトデータを構築した「Manga109Script」を提案しています。主な目的は、物語のスクリプトを使用して一貫性のある表現力豊かなマンガのレイアウトを生成する「Script2Layout」タスクを実現することです。GPT-4などのVision Large Language Models（VLLMs）を活用して、シーン見出し、アクション説明、対話を含むスクリプトを生成しています。著者らは複数のScript2Layoutモデルを開発・評価し、スクリプト情報を組み込むことで、既存手法と比較してレイアウト生成の品質が大幅に向上することを実証しています。データセットと関連コードは論文公開時に利用可能となり、マンガレイアウト生成とビジュアルストーリーテリング研究の貴重なリソースとなります。
    
    **長所：**
    
    1. Manga109Scriptは、大規模なスクリプト連携データセットを提供することで、マンガレイアウト生成分野における重要なギャップを埋めています。これにより、データ不足により研究が進んでいなかったスクリプトベースのレイアウト生成の探求が可能になりました。
    2. 著者らは、ビジュアルプロンプティングと発話者を意識した対話シーケンスを用いて、VLLMsによるスクリプト生成の堅牢な手法を採用しています。GPT-4との多段階的な相互作用により、スクリプトが文脈的に一貫し、元のマンガの物語と整合することを保証しています。
    3. シーン見出しのリコール率、シーン見出しの精度、アクション説明の精度、文脈外アクション説明の検出精度、対話のリコール率などの人的評価指標により、データセットの品質の信頼性が示され、下流タスクへの信頼性が実証されています。
    4. 論文は問題定式化、データ構築プロセス、実験セットアップについて明確な説明がなされており、図表が重要なポイントと結果を効果的に説明するために使用されています。
    
    **短所：**
    
    1. スクリプト生成プロセスがGPT-4に依存しています。この依存性は再現性と信頼性に関する懸念を引き起こす可能性があります。
    2. 論文は定量的・定性的評価を提供していますが、詳細なエラー分析が欠けています。Script2Layoutモデルの一般的な失敗モードを理解することで、より深い洞察が得られ、将来の改善の指針となる可能性があります。
    3. 評価は主に既存のレイアウト生成手法との比較に焦点を当てています。代替的なスクリプト生成技術の探求や複数のVLLMsの統合により、実験部分をより強化できる可能性があります。
    
    **評価：** 6：受理閾値をわずかに上回る
    
    **確信度：** 4：評価が正しいことについて確信はあるが、絶対的な確信ではない
    
    **適合性：** 明確にマルチメディア論文であり、コミュニティの大部分にとって興味深い内容
    
    **適合性の根拠：** Script2Layoutはマルチメディアタスクである。
    
    **技術的品質：** 5
    
    **プレゼンテーション品質：** 6
    
    **リバタルへの質問：** 短所の部分を参照してください。
    
    **追加コメント：**
    
- 先生のコメント
    1. GPT-4 に頼りすぎていて、Script の生成における再現性と信頼性が保証されてないのでは？← 同様な手法を扱っている論文をそろえる
    2. 失敗例に関する評価が足りていない ← Appendix に書いてあることを伝えつつ、さらに補足的な分析があれば述べる。そしてこのことは、camera rady には載せるということを主張する
    3. 他の脚本生成での分析や VLLM を組み込みこむことでの評価は ? ← このような分析がなくても通っている論文を示す

## Reviewer 2

- Review 本文
    
    **This paper presents an practical approach to manga layout generation by incorporating script information. The research is well-structured, addressing a clear problem in the field of creative AI and manga production. The authors provide comprehensive experiments and evaluations, comparing their approach with existing methods. While the work shows promise in improving layout generation, there are some concerns regarding the technical innovation in script construction and the depth of dataset application evaluation.**
    
    Official Reviewby Reviewer wi4V19 May 2025, 17:08 (modified: 09 Jun 2025, 23:38)Program Chairs, Senior Area Chairs, Area Chairs, Reviewer wi4V, Authors[Revisions](https://openreview.net/revisions?id=trwyYeYsLZ)
    
    **Review:**
    
    The paper introduces Manga109Script, a novel dataset linking scripts to manga layouts for approximately 20,000 pages from the Manga109 dataset. The authors propose a task called Script2Layout to generate manga layouts directly from scripts. They use Vision Large Language Models (VLLMs) to create script data and develop manga layout generation models that take scripts as input. The research compares these Script2Layout models with existing layout generation methods under various constraints, demonstrating improved performance, especially in mean Intersection over Union (mIoU) metrics.
    
    Pros: 1. The paper clearly defines the Script2Layout task and provides a thorough explanation of the Manga109Script dataset creation process. The methodology, experiments, and results are described in detail, giving readers a comprehensive understanding of the research. 2. The research addresses a practical problem in manga production, potentially bridging the gap between narrative scripts and visual layouts. The extensive evaluation using both quantitative metrics (FID, mIoU) and qualitative analysis demonstrates the effectiveness of the proposed approach.
    
    Cons: 1. While the paper presents a new dataset and task, the script/data generation process relies heavily on existing VLLMs and rule-based algorithms. While the process attempts to address narrative continuity across pages, it primarily focuses on structuring interactions with GPT-4o. There is limited innovation in how narrative continuity is maintained or enhanced, especially given the constraint of limited token length. This could impact the coherence and fluidity of the generated scripts across multiple pages. The technical innovation in script construction appears limited, as it primarily combines existing technologies rather than introducing novel algorithms or methods. 2. Although the paper provides extensive evaluations of the Script2Layout models, the assessment of the dataset's broader applications and potential impact on the field could be more comprehensive. The research focuses primarily on layout generation, but it could benefit from exploring other potential uses of the Manga109Script dataset or discussing its limitations and potential biases.
    
    Minor Issues: 1. Line 120: Typo Section 2.1: “unaerexplored” should be “underexplored”; 2. Line 150: “oppotunities” should be “opportunities”;
    
    **Rating:** 5: Marginally below acceptance threshold
    
    **Confidence:** 4: The reviewer is confident but not absolutely certain that the evaluation is correct
    
    **Fit:** Relevant to a part of the community
    
    **Fit Justification:**
    
    The paper fits well with the ACM Multimedia community as it bridges computer vision and natural language processing in multimedia content creation. It introduces a novel dataset and task that enhance visual storytelling, aligning with the community's focus on multimedia analysis and generation
    
    **Technical Quality:** 4
    
    **Presentation Quality:** 7
    
    **Rebuttal Questions:**
    
    Here are some questions for the authors to address during the rebuttal:
    
    1. Technical Innovation: Can you elaborate on the specific technical innovations introduced in the process of constructing manga scripts using VLLMs? How does this approach differ from existing methods?
    2. Dataset Applications: Could you provide more details on the potential applications of the Manga109Script dataset beyond layout generation? How might this dataset be utilized in other areas of multimedia research or industry?
    3. Limitations and Future Work: What are the current limitations of your approach, and what future work do you envision to address these challenges? How might you improve the integration of script information into layout generation?
    
    **Additional Comments:**
    
    No
    
- 日本語訳
    
    本論文は、スクリプト情報を組み込むことでマンガのレイアウト生成に対する実用的なアプローチを提示しています。この研究は、クリエイティブAIとマンガ制作分野における明確な課題に取り組んでおり、構造が整っています。著者らは包括的な実験と評価を提供し、既存手法との比較を行っています。レイアウト生成の改善において有望な結果を示していますが、スクリプト構築における技術的革新性とデータセット応用評価の深さについていくつかの懸念があります。
    
    **レビュー内容：**
    
    本論文はManga109Scriptを紹介しています。これはManga109データセットから約20,000ページのマンガのレイアウトとスクリプトをリンクさせた新しいデータセットです。著者らはScript2Layoutと呼ばれるタスクを提案し、スクリプトから直接マンガのレイアウトを生成します。Vision Large Language Models (VLLMs)を使用してスクリプトデータを作成し、スクリプトを入力として受け取るマンガレイアウト生成モデルを開発しています。この研究では、様々な制約下でこれらのScript2Layoutモデルを既存のレイアウト生成手法と比較し、特に平均Intersection over Union (mIoU)指標において改善された性能を示しています。
    
    **長所：**
    
    1. 論文はScript2Layoutタスクを明確に定義し、Manga109Scriptデータセット作成プロセスについて詳細な説明を提供しています。方法論、実験、結果が詳細に記述されており、読者に研究の包括的な理解を与えています。
    2. この研究はマンガ制作における実践的な問題に取り組み、物語のスクリプトとビジュアルレイアウトの間のギャップを埋める可能性を持っています。定量的指標（FID、mIoU）と定性的分析の両方を用いた広範な評価により、提案手法の有効性が実証されています。
    
    **短所：**
    
    1. 論文は新しいデータセットとタスクを提示していますが、スクリプト/データ生成プロセスは既存のVLLMsとルールベースのアルゴリズムに大きく依存しています。ページ間の物語の連続性に対処しようとしていますが、主にGPT-4oとの相互作用の構造化に焦点を当てています。特にトークン長の制限を考慮すると、物語の連続性がどのように維持・強化されるかについての革新性は限定的です。これは複数ページにわたるスクリプトの一貫性と流動性に影響を与える可能性があります。スクリプト構築における技術的革新性は、新しいアルゴリズムや手法を導入するというよりも、既存の技術を組み合わせているに過ぎないように見えます。
    2. 論文はScript2Layoutモデルの広範な評価を提供していますが、データセットのより広い応用可能性とその分野への潜在的な影響の評価をより包括的にする余地があります。研究は主にレイアウト生成に焦点を当てていますが、Manga109Scriptデータセットの他の潜在的な用途を探求したり、その制限やバイアスについて議論したりすることで、さらに充実した内容になる可能性があります。
    
    **細かな問題点：**
    
    1. 120行目：セクション2.1の"unaerexplored"は"underexplored"の誤字
    2. 150行目："oppotunities"は"opportunities"の誤字
    
    **評価：** 5：受理閾値をわずかに下回る
    
    **確信度：** 4：評価が正しいことについて確信はあるが、絶対的な確信ではない
    
    **適合性：** コミュニティの一部に関連性がある
    
    **適合性の根拠：**
    本論文は、マルチメディアコンテンツ作成におけるコンピュータビジョンと自然言語処理の橋渡しをするものであり、ACMマルチメディアコミュニティに適合しています。視覚的ストーリーテリングを強化する新しいデータセットとタスクを導入しており、マルチメディア分析と生成に焦点を当てるコミュニティの方向性に合致しています。
    
    **技術的品質：** 4
    
    **プレゼンテーション品質：** 7
    
    **リバタルへの質問：**
    以下の質問について、リバタルで著者からの回答を求めます：
    
    1. 技術的革新性：VLLMsを使用したマンガスクリプト構築プロセスにおける具体的な技術的革新について詳しく説明できますか？この手法は既存の手法とどのように異なりますか？
    2. データセットの応用：レイアウト生成以外のManga109Scriptデータセットの潜在的な応用について、より詳細な情報を提供できますか？このデータセットはマルチメディア研究や産業の他の分野でどのように活用できる可能性がありますか？
    3. 制限事項と今後の展望：現在のアプローチの制限は何で、これらの課題に対処するためにどのような今後の研究を想定していますか？スクリプト情報のレイアウト生成への統合をどのように改善できますか？
    
    **追加コメント：**
    なし
    
- 先生からのコメント
    
    2と3はこの人独自の質問だが、回答できそう？そもそも、漫画が思っているより広い市場と応用を持っているって思ってもらう方が無難かな。文化圏の差とかがありそうなら、それも認識してもらう。フランス人とか、漫画は子どものもので大人が触れるものではないって意識の人は自分以上の世代だととても多いから。
    
    → 自分の回答: 2 の質問について、漫画市場が拡大しておいることと、脚本からレイアウトを生成する研究は、映画やアニメにおける絵コンテの生成など、他の映像分野の研究に応用可能性を持っていることが回答になると考えます。 
    
    先生: これに加えて、漫画自体も情報伝達のフォーマットとして広告や教材など、単なる娯楽以上の広がりがあることをいっておくのは良さそうですね。
    

## Reviewer 3

- Review 本文
    
    **Work of dataset developed on exsiting images with LLM generated annotations and corresponding evaluation experiments**
    
    Official Reviewby Reviewer zWvJ16 May 2025, 00:39 (modified: 09 Jun 2025, 23:38)Program Chairs, Senior Area Chairs, Area Chairs, Reviewer zWvJ, Authors[Revisions](https://openreview.net/revisions?id=H0NNw0ysu5)
    
    **Review:**
    
    This paper presents Manga109Script dataset that consist of manga layout data generated from given script from Manga109 dataset. The authors used Vision Large Language Models (VLLMs) to generate scripts from the Manga109 dataset based on the unique narrative structure of manga, and employed visual prompting and speaker-aware dialogue sequencing to create high-quality script data. The authors also developed and evaluated manga layout generation models based on the proposed dataset and several LLMs, which prove that the script information improves layout generation quality compared to existing methods.
    
    Pros:
    
    1. The idea of generating manga layout from scripts by VLM and vice verse sounds novel and interesting
    2. The experiments seem adequate to validate the performance of the manga layout generation models developed on the dataset
    
    Cons:
    
    1. The dataset is based on existing manga image dataset and VLM generated prompts, and the manga layout generation models are based on existing LLM models, making the contribution limited
    2. The diversity of the images in the dataset seems to be limited. For example, there are only Japanese manga of many years ago, and all images seem to be black and white, which may limit the potential application
    3. The scripts are generated by VLM, and the Script2Layout models trained on the dataset are based on existing LLMs. The performance gap may be because of the distribution bias between the VLM and the LLM
    
    **Rating:** 4: Ok but not good enough - rejection
    
    **Confidence:** 3: The reviewer is fairly confident that the evaluation is correct
    
    **Fit:** Relevant to a part of the community
    
    **Fit Justification:**
    
    This paper presents a manga dataset with scripts, which do involve multimedia, but personally I believe computer vision or computer graphic conferences/journals are better fit
    
    **Technical Quality:** 4
    
    **Presentation Quality:** 5
    
    **Rebuttal Questions:**
    
    1. Will the dataset be publicly available?
    2. Is the dataset preparation pipeline effective to color images or comics of other languages?
    3. How to eliminate the influence of VLM used to annotate the images and the LLMs used in Script2Layout models?
    
    **Additional Comments:**
    
    This work is potentially beneficial to both ML society and comic industry. However, I think the the currently quality is slightly below the bar of ACMMM. It would make the contribution more solid if there are larger amount of more recent and more diverse data, like color images, comics with different languages, comics of different styles. Also, it would be more convincing if there are feedbacks from artists/readers.
    
    - 日本語訳
        
        この論文は、Manga109データセットから与えられたスクリプトから生成されたマンガレイアウトデータで構成されるManga109Scriptデータセットを提案しています。著者らは、マンガ特有の物語構造に基づいてManga109データセットからスクリプトを生成するために Vision Large Language Models (VLLMs) を使用し、視覚的プロンプトとスピーカーを意識したダイアログシーケンスを採用して高品質なスクリプトデータを作成しました。また、提案されたデータセットと複数のLLMsに基づいてマンガレイアウト生成モデルを開発・評価し、スクリプト情報が既存手法と比較してレイアウト生成の品質を向上させることを証明しています。
        
        **長所：**
        
        1. VLMによるスクリプトからのマンガレイアウト生成（およびその逆）というアイデアは斬新で興味深い
        2. データセットで開発されたマンガレイアウト生成モデルの性能を検証する実験は適切に行われている
        
        **短所：**
        
        1. データセットは既存のマンガ画像データセットとVLMで生成されたプロンプトに基づいており、マンガレイアウト生成モデルは既存のLLMモデルに基づいているため、貢献度が限定的
        2. データセット内の画像の多様性が限られている。例えば、何年も前の日本のマンガのみで、すべての画像が白黒であり、潜在的な応用を制限する可能性がある
        3. スクリプトはVLMによって生成され、データセットで訓練されたScript2Layoutモデルは既存のLLMsに基づいている。性能の差はVLMとLLM間の分布バイアスによる可能性がある
        
        **評価：** 4：まあまあだが十分ではない - 不採択
        
        **確信度：** 3：評価が正しいことについてかなりの確信がある
        
        **適合性：** コミュニティの一部に関連性がある
        
        **適合性の根拠：**
        この論文はスクリプト付きのマンガデータセットを提示しており、マルチメディアは関係していますが、個人的にはコンピュータビジョンやコンピュータグラフィックスの会議/ジャーナルの方が適していると考えます。
        
        **技術的品質：** 4
        
        **プレゼンテーション品質：** 5
        
        **リバタルへの質問：**
        
        1. データセットは公開される予定ですか？
        2. データセット作成パイプラインはカラー画像や他言語のコミックに対しても効果的ですか？
        3. 画像のアノテーションに使用されたVLMとScript2Layoutモデルで使用されたLLMsの影響をどのように排除しますか？
        
        **追加コメント：**
        この研究はML社会とコミック産業の両方に潜在的に有益です。しかし、現在の品質はACMMMの基準をわずかに下回っていると考えます。カラー画像、異なる言語のコミック、異なるスタイルのコミックなど、より最近の、より多様なデータが大量にあれば、貢献度がより確実なものになるでしょう。また、アーティスト/読者からのフィードバックがあれば、より説得力のあるものになるでしょう。
        
- 日本語訳
    
    既存画像とLLM生成アノテーション、および対応する評価実験に基づくデータセットの成果
    
    公式レビュー (レビュアー zWvJ)
    
    2025年5月16日 00:39 (修正: 2025年6月9日 23:38)
    
    プログラム委員長、シニアエリアチェア、エリアチェア、レビュアー zWvJ、著者
    
    **レビュー:**
    
    本論文は、Manga109データセットから与えられたスクリプトに基づいて生成された漫画レイアウトデータから構成されるManga109Scriptデータセットを提示しています。著者らは、漫画独自の物語構造に基づき、Vision Large Language Models (VLLMs) を用いてManga109データセットからスクリプトを生成し、ビジュアルプロンプティングと話者認識対話シーケンスを採用して高品質なスクリプトデータを作成しました。著者らはまた、提案されたデータセットといくつかのLLMに基づいて漫画レイアウト生成モデルを開発し、評価しました。これにより、既存の手法と比較して、スクリプト情報がレイアウト生成品質を向上させることが証明されました。
    
    **長所:**
    
    - VLMと、その逆でスクリプトから漫画レイアウトを生成するというアイデアは斬新で興味深い。
    - データセット上で開発された漫画レイアウト生成モデルの性能を検証する上で、実験は適切に見える。
    
    **短所:**
    
    - データセットは既存の漫画画像データセットとVLMが生成したプロンプトに基づいており、漫画レイアウト生成モデルは既存のLLMモデルに基づいているため、貢献が限定的である。
    - データセット内の画像の多様性が限られているように見える。例えば、かなり昔の日本の漫画しかなく、すべての画像が白黒であるため、潜在的な応用が制限される可能性がある。
    - スクリプトはVLMによって生成されており、データセットで訓練されたScript2Layoutモデルは既存のLLMに基づいている。性能差は、VLMとLLM間の分布バイアスに起因する可能性がある。
    
    **評価:** 4: 悪くはないが十分ではない - 不採択
    
    **確信度:** 3: レビュアーは評価が正しいとかなり確信している。
    
    **適合性:** コミュニティの一部に関連性がある。
    
    適合性の根拠:
    
    本論文は、スクリプト付きの漫画データセットを提示しており、マルチメディアを含みますが、個人的には、コンピュータビジョンまたはコンピュータグラフィックスの会議/ジャーナルがより適していると考えます。
    
    技術的品質: 4
    
    発表品質: 5
    
    **反論に関する質問:**
    
    - データセットは公開される予定ですか？
    - データセット準備パイプラインは、カラー画像や他の言語のコミックにも効果的ですか？
    - 画像の注釈付けに使用されたVLMと、Script2Layoutモデルで使用されたLLMの影響をどのように排除しますか？
    
    **追加コメント:**
    
    本研究は、MLコミュニティとコミック業界の両方に潜在的に有益です。しかし、現在の品質はACMMMの基準をわずかに下回っていると思います。より最近の、より多様なデータ（カラー画像、異なる言語のコミック、異なるスタイルのコミックなど）が大量にあれば、貢献はより確固たるものになるでしょう。また、アーティストや読者からのフィードバックがあれば、より説得力が増すでしょう。
    
- 先生からのコメント
    
    > Will the dataset be publicly available?
    > 
    
    には、yesで
    
    > Is the dataset preparation pipeline effective to color images or comics of other languages?
    > 
    
    → Yesを多少の根拠とともに示せばOK。例えばvisual promptingは元々color imageに対して行われているし、むしろinformationが増えるからやりやすいはず、とか、言語に特有の何かは使っていないので、他の言語で動かないと考える合理的な理由がない、もっとspecificに指摘を貰えると今後の参考になり、嬉しい、といって査読者に適当であることを許さないようにする、とか。
    
    > How to eliminate the influence of VLM used to annotate the images and the LLMs used in Script2Layout models?
    > 
    
    → これも、Performance gapの項目のことだと思うが、ちょっとよくわからない…
    
    自分の感想: おそらくこの reviewer は、VLLMを使って、その script を作ったのだから、その VLLM と近しい分布を持っている LLM があれば、そこからが画像を再構成するときに、その分布の利点を使って、より精度の高い、レイアウトを生成してしまえるのでは？と言っていると思われる。→ 画像情報としての特徴量と生成されるレイアウトの数値情報は、その形態の違いから特徴量空間において十分に乖離したものになっていると考えられるので、このような影響は無視できるほど小さいと考える。
    

## Reviewer4

- Review 本文
    
    **Review of Submission #4528**
    
    Official Reviewby Reviewer ZqvN05 May 2025, 09:52 (modified: 09 Jun 2025, 23:38)Program Chairs, Senior Area Chairs, Area Chairs, Reviewer ZqvN, Authors[Revisions](https://openreview.net/revisions?id=k5ZYPfvtZV)
    
    **Review:**
    
    This paper constructs the Manga109Script dataset that creates script data for approximately 20,000 pages from the existing Manga109 dataset. An annotation-assisted method is introduced to generate script data from manga images using existing VLLMs. Several baselines are used for the script-based layout generation task. However, the contribution of the whole data creation process is not very clear. The key idea of this paper is to create a new dataset that could support script-based manga layout generation. However, the proposed dataset comes from the existing Manga109script dataset. The script data is generated by existing VLMs. The only contribution is the human evaluation process for quality verification. I cannot see new insights for the proposed benchmark.
    
    **Rating:** 4: Ok but not good enough - rejection
    
    **Confidence:** 4: The reviewer is confident but not absolutely certain that the evaluation is correct
    
    **Fit:** Very clearly a multimedia paper, of interest to a large part of the community
    
    **Fit Justification:**
    
    This paper focuses on the manga image understanding task, which includes multiple subtasks that align with the ACM Multimedia Topics of Interest.
    
    **Technical Quality:** 5
    
    **Presentation Quality:** 5
    
    **Rebuttal Questions:**
    
    1. The difference between the proposed Scirpt2Layout and the existing layout generation model is also not clear. As shown in Fig.2, it is not difficult to extract elements from the script (using rule-based or LLM-based processing) for existing layout generation models.
    2. The current evaluation metrics and compared methods are not thorough. Additional geometric and content-aware evaluation metrics are necessary to evaluate the layout quality. In addition, existing content-aware layout generation methods, including PosterLlama and LVMs, should be compared and discussed in the experiments.
    
    **Additional Comments:**
    
    As this paper focuses on the script2layout task, it would be better to show the script data in the qualitative comparisons.
    
    - 日本語訳
        
        この論文は、既存のManga109データセットから約20,000ページ分のスクリプトデータを作成するManga109Scriptデータセットを構築しています。既存のVLLMsを使用してマンガ画像からスクリプトデータを生成する注釈支援手法が導入されています。スクリプトベースのレイアウト生成タスクに対していくつかのベースラインが使用されています。しかし、データ作成プロセス全体の貢献度が明確ではありません。この論文の主要なアイデアは、スクリプトベースのマンガレイアウト生成をサポートできる新しいデータセットを作成することですが、提案されたデータセットは既存のManga109Scriptデータセットから得られたものです。スクリプトデータは既存のVLMsによって生成されており、唯一の貢献は品質検証のための人間による評価プロセスです。提案されたベンチマークに新しい洞察を見出すことができません。
        
        **評価：** 4：まあまあだが十分ではない - 不採択
        
        **確信度：** 4：評価が正しいことについてかなりの確信があるが、完全に確信しているわけではない
        
        **適合性：** 明確にマルチメディア論文であり、コミュニティの大部分にとって関心のあるもの
        
        **適合性の根拠：**
        この論文はマンガ画像理解タスクに焦点を当てており、ACMマルチメディアの関心トピックに合致する複数のサブタスクを含んでいます。
        
        **技術的品質：** 5
        
        **プレゼンテーション品質：** 5
        
        **リバタルへの質問：**
        
        1. 提案されたScript2Layoutと既存のレイアウト生成モデルとの違いが明確ではありません。図2に示されているように、既存のレイアウト生成モデルに対して（ルールベースまたはLLMベースの処理を使用して）スクリプトから要素を抽出することは難しくありません。
        2. 現在の評価指標と比較手法が十分ではありません。レイアウトの品質を評価するために、追加の幾何学的およびコンテンツを考慮した評価指標が必要です。さらに、PosterLlamaやLVMsを含む既存のコンテンツを考慮したレイアウト生成手法を実験で比較・議論する必要があります。
        
        **追加コメント：**
        この論文はscript2layoutタスクに焦点を当てているため、定性的比較でスクリプトデータを示す方が良いでしょう。
        
- 日本語訳
    
    提出物 #4528 のレビュー
    
    公式レビュー (レビュアー ZqvN)
    
    2025年5月5日 09:52 (修正: 2025年6月9日 23:38)
    
    プログラム委員長、シニアエリアチェア、エリアチェア、レビュアー ZqvN、著者
    
    **レビュー:**
    
    本論文は、既存のManga109データセットから約20,000ページ分のスクリプトデータを作成するManga109Scriptデータセットを構築しています。既存のVLLMを用いて漫画画像からスクリプトデータを生成するアノテーション補助手法が導入されています。スクリプトベースのレイアウト生成タスクにはいくつかのベースラインが使用されています。しかし、データ作成プロセス全体の貢献はあまり明確ではありません。本論文の主なアイデアは、スクリプトベースの漫画レイアウト生成をサポートできる新しいデータセットを作成することです。しかし、提案されたデータセットは既存のManga109データセットから派生しており、スクリプトデータは既存のVLMによって生成されています。唯一の貢献は、品質検証のための人間による評価プロセスです。提案されたベンチマークに新しい洞察は見られません。
    
    **評価:** 4: 悪くはないが十分ではない - 不採択
    
    **確信度:** 4: レビュアーは評価が正しいと確信しているが、絶対的な確実性はない。
    
    **適合性:** 非常に明確なマルチメディア論文であり、コミュニティの大部分にとって興味深い。
    
    適合性の根拠:
    
    本論文は、漫画画像理解タスクに焦点を当てており、ACMマルチメディアの関心分野に合致する複数のサブタスクを含んでいます。
    
    技術的品質: 5
    
    発表品質: 5
    
    **反論に関する質問:**
    
    - 提案されたScript2Layoutと既存のレイアウト生成モデルとの違いも明確ではありません。図2に示されているように、既存のレイアウト生成モデルにとって、スクリプトから要素を抽出すること（ルールベースまたはLLMベースの処理を使用）は難しくありません。
    - 現在の評価指標と比較手法は徹底されていません。レイアウト品質を評価するには、追加の幾何学的およびコンテンツ認識型の評価指標が必要です。さらに、PosterLlamaやLVMを含む既存のコンテンツ認識型レイアウト生成手法も、実験で比較・議論されるべきです。
    
    **追加コメント:**
    
    本論文はscript2layoutタスクに焦点を当てているため、定性的な比較でスクリプトデータを示すと良いでしょう。
    
- 先生からのコメント
    
    

---

# GoodNote

---

[Reviewの分析およびPosterLlamaについての確認.pdf](ACMMM2025%20%E3%83%AA%E3%83%8F%E3%82%99%E3%82%BF%E3%83%AB%20Rebuttal%20%E6%BA%96%E5%82%99%2020f6833ec28b804394c2f2cddc2c220a/Review%E3%81%AE%E5%88%86%E6%9E%90%E3%81%8A%E3%82%88%E3%81%B2%E3%82%99PosterLlama%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%AE%E7%A2%BA%E8%AA%8D.pdf)

[Reviewの分析およびPosterLlamaについての確認_2.pdf](ACMMM2025%20%E3%83%AA%E3%83%8F%E3%82%99%E3%82%BF%E3%83%AB%20Rebuttal%20%E6%BA%96%E5%82%99%2020f6833ec28b804394c2f2cddc2c220a/Review%E3%81%AE%E5%88%86%E6%9E%90%E3%81%8A%E3%82%88%E3%81%B2%E3%82%99PosterLlama%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%AE%E7%A2%BA%E8%AA%8D_2.pdf)

# e-mail announce from [tpc@acmmm2025.org](mailto:tpc@acmmm2025.org), tpc(technical Program Comittee)

### 1

- 本文
    
    Dear Kengo Watanabe,
    
    According to the timeline, the reviews have been released on Monday June 9, 2025. We have secured at least three reviews for each submission, while most submissions have received four or five reviews.
    
    As announced on the conference website and the OpenReview submission form, papers co-authored by authors that did not contribute to the review process by completing their assignments - despite numerous reminders and deadline extensions - will not receive reviews at this stage. In contrast to other conferences of this size, we will not desk-reject the affected papers, but instead the authors of the affected papers will not be able to see the reviews during the rebuttal period and, therefore, won’t be able to participate in the rebuttal.
    
    Unfortunately, OpenReview is currently experiencing technical difficulties with the rebuttal comment process, presumably due to recent updates to the platform, which is affecting multiple venues including ACM Multimedia. We are in contact with OpenReview to find a solution as quickly as possible. We are as frustrated by this delay as you are and will keep you updated as soon as the OpenReview team has resolved the issue. Due to this delay, the rebuttal deadline will also be extended, with more information to follow soon.
    
    When there is something clearly wrong with the reviews, consult the Author's Advocate guidelines to assess whether you should make a request for mediation:
    
    [https://acmmm2025.org/authors-advocate/](https://acmmm2025.org/authors-advocate/)
    
    To all the hundreds of you who emailed us, we hear you, we are not ignoring you, and we will get back to you as soon as we can. We are all in this together and appreciate your patience with this. As soon as OpenReview has the rebuttal process back, we will continue with the regularly scheduled programming.
    
    Sincerely yours,
    
    Jenny, Luca, Phoebe, Stevan, Tien, and Wen-Huang
    
    Technical Program Chairs
    
    Please note that responding to this email will direct your reply to [tpc@acmmm2025.org](mailto:tpc@acmmm2025.org).
    
- 要点
    
    このメールの重要ポイント：
    
    - レビュー公開について：
        - 2025年6月9日（月）にレビューが公開
        - 各論文に対して最低3件、多くは4-5件のレビューを確保
    - レビュー担当者としての義務について：
        - レビュー担当を完了しなかった著者の論文は、この段階でレビューを閲覧できない
        - デスクリジェクトはされないが、リバタル期間中にレビューを見ることができず、リバタルにも参加できない
    - システムの技術的問題：
        - OpenReviewでリバタルコメントプロセスに技術的な問題が発生
        - 解決に向けて対応中
        - リバタルの締切は延長予定
    - レビューに問題がある場合：
        - Author's Advocate（著者擁護者）のガイドラインを参照
        - 調停要請が必要かどうかを判断することを推奨
    - 問い合わせについて：
        - 多数のメールを受け取っており、順次対応予定
        - OpenReviewのリバタルプロセスが復旧次第、通常のスケジュールを再開

### 2

- 本文
    
    Dear Kengo Watanabe,
    
    The rebuttal option is now available on OpenReview. To compensate for the delay caused by the technical issues, we extended the deadline for rebuttals to 19 June 2025 (AoE). We again apologise for any inconvenience this may have caused.
    
    To respond to the reviews, please follow the instructions below.
    
    1. Log into OpenReview and select ACMMM 2025 Conference Authors in Your Active Consoles.
    2. Go to the paper for which you would like to post a rebuttal and carefully read reviewer comments.
    3. Click on the button Rebuttal to add one rebuttal per review.
    4. Address reviewer comments in a concise manner, indicating which review you are responding to. The rebuttals should be self-contained and should not contain links to the external materials such as code and videos.
    5. Note that the rebuttal must maintain anonymity.
    
    The instructions can also be found on the following page: [https://acmmm2025.org/information-for-authors/](https://acmmm2025.org/information-for-authors/)
    
    Sincerely yours,
    
    Jenny, Luca, Phoebe, Stevan, Tien, and Wen-Huang
    
    Technical Program Chairs
    
    Please note that responding to this email will direct your reply to [tpc@acmmm2025.org](mailto:tpc@acmmm2025.org).
    
- 要点
    
    このメールの重要ポイント：
    
    - リバタルの提出期限：2025年6月19日 AoE まで延長
    - 提出手順：
        - OpenReviewにログインし、「ACMMM 2025 Conference Authors」を選択
        - 対象論文のレビューを確認
        - 各レビューに対して個別にリバタルを提出（「Rebuttal」ボタンを使用）
        - レビューへの返答は簡潔に、どのレビューに対する返答かを明確に
        - 外部リンク（コードやビデオ）は含めない
    - 重要な注意事項：
        - 匿名性を維持すること
        - 各リバタルは自己完結的であること

### 3

- 本文
    
    Dear Kengo Watanabe,
    
    We have received multiple requests for clarification about the rebuttal formatting. As communicated in our previous email, you should follow these steps to submit your rebuttals:
    
    - Log into OpenReview and select ACMMM 2025 Conference Authors in Your Active Consoles
    - Go to the paper for which you would like to post a rebuttal and carefully read reviewer comments
    - Click on the button Rebuttal to add one rebuttal per review.
    - Address reviewer comments in a concise manner, indicating which review you are responding to. The rebuttals should be self-contained and should not contain links to the external materials such as code and videos.
    - Note that the rebuttal must maintain anonymity.
    
    Rebuttal instructions are also available on the following page: [https://acmmm2025.org/information-for-authors/](https://acmmm2025.org/information-for-authors/)
    
    Below are the answers to some frequently asked questions:
    
    - What does "Click on the button Rebuttal to add one rebuttal per review." mean? This means that if you have received N reviews (e.g. N=3) you should repeat the procedure N times to add N rebuttals (i.e. one per review). If you received 3 reviews, you should add 3 rebuttals. If you received 4 reviews, you should add 4 rebuttals etc.
    - Is it possible to edit or delete the rebuttal? Yes, you can edit or delete rebuttal during the rebuttal period, which ends on 19.06.2025 23:59 AoE.
    - Can I add an image to my Rebuttal? As per OpenReview documentation, the platform does not support images.
    - How can I format text of the rebuttal? As noted in OpenReview Rebuttal form, which opens once you click on the button Rebuttal: "Rebuttals can include Markdown formatting and LaTeX forumulas, for more information see [https://openreview.net/faq](https://openreview.net/faq)"
    
    Have a nice weekend!
    
    Sincerely yours,
    
    Jenny, Luca, Phoebe, Stevan, Tien, and Wen-Huang
    
    Technical Program Chairs
    
    Please note that responding to this email will direct your reply to [tpc@acmmm2025.org](mailto:tpc@acmmm2025.org).x
    
- 要点
    
    このメールのポイント：
    
    - リバタルの提出方法について：
        - OpenReviewにログインし、ACMMM 2025 Conference Authorsを選択
        - 対象論文のレビューを確認
        - 各レビューに対して1つずつリバタルを提出（例：3つのレビューに対して3つのリバタル）
        - 外部リンクや画像は含めないこと
        - 匿名性を保持すること
    - リバタルの編集・削除：
        - 期限（2025年6月19日23:59 AoE）まで可能
    - フォーマットについて：
        - 画像は使用不可
        - MarkdownとLaTeXの数式が使用可能
    - 締切：2025年6月19日23:59 AoE